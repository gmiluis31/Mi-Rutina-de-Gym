# Ficha de Google Play (copiar y pegar)

**Nombre (máx. 30):** Mi rutina de gym

**Descripción breve (máx. 80):**
Planifica tu semana de entrenamiento y marca tus series al terminar.

**Descripción completa (máx. 4000):**
Organiza tu semana de gimnasio en un solo lugar, sin cuentas ni anuncios.

• Planifica cada día de la semana con su enfoque: pecho, espalda, pierna, descanso…
• Añade ejercicios con series, repeticiones y peso.
• Marca cada serie mientras entrenas y mira tu avance del día.
• Empieza rápido con plantillas: Push / Pull / Pierna, Torso / Pierna o Cuerpo completo.
• Tema claro y oscuro.
• Tus datos se quedan en tu dispositivo. Funciona sin conexión.

**Categoría:** Salud y bienestar (o Deportes)
**Etiquetas:** fitness, entrenamiento, rutina
**Clasificación de contenido:** cuestionario IARC → sin violencia, sin compras, sin anuncios
**Seguridad de los datos:** "No se recopilan datos" / "No se comparten datos"
**Anuncios:** No · **Compras:** No
**Gráficos:** icono → store/icono-512.png · gráfico de función → store/grafico-funcion-1024x500.png
**Capturas:** mínimo 2 de teléfono (haz capturas de la app en tu móvil)
