# Política de privacidad — Mi rutina de gym

Última actualización: [FECHA]

Mi rutina de gym no recopila, transmite ni comparte datos personales.
Las rutinas, ejercicios y progreso que registras se guardan únicamente en tu dispositivo.
La app no requiere cuenta, no usa servicios de analítica ni publicidad y no accede a tu ubicación, contactos, cámara ni micrófono.
Si desinstalas la app o borras sus datos, la información guardada se elimina.

Contacto: [TU CORREO]
